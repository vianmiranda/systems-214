echo hello worlds
then ls
echo testenv/lol.txt
ls
cat testenv/lol.txt | cat
cat testenv/lol.txt | echo
echo exit
else echo else 1
else echo else 2
